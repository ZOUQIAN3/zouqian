package Facade;

public class NationalDebt3 {
	public void sell(){
		System.out.println("国债3卖出");
	}
	public void buy(){
		System.out.println("国债3买入");
	}
}
